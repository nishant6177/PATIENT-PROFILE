package com.example.patientprofile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HistoryActivity extends AppCompatActivity {

    TextView PName, PAge, PGender, PSymptoms, PMobile, PDate, PTime;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        PName = findViewById(R.id.PName);
        PAge = findViewById(R.id.PAge);
        PGender = findViewById(R.id.PGender);
        PSymptoms = findViewById(R.id.PSymptoms);
        PMobile = findViewById(R.id.PMobile);
        PDate = findViewById(R.id.PDate);
        PTime = findViewById(R.id.PTime);
        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        FirebaseDatabase.getInstance().getReference().child("AppointInfo").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                AppointInfo appointInfo = snapshot.getValue(AppointInfo.class);
                PName.setText(appointInfo.getName());
                PAge.setText(appointInfo.getAge());
                PGender.setText(appointInfo.getGender());
                PSymptoms.setText(appointInfo.getSymptoms());
                PMobile.setText(appointInfo.getMobile());
                PDate.setText(appointInfo.getDate());
                PTime.setText(appointInfo.getTime());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}