package com.example.patientprofile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class DoctorsActivity extends AppCompatActivity {

    Button next, Book_1, call_1, call_2, Book_2, call_3, Book_3;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);

        next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorsActivity.this, Doctors1.class);
                startActivity(intent);
            }
        });

        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Book_1 = findViewById(R.id.Book_1);
        Book_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorsActivity.this, appointment.class);
                startActivity(intent);
            }
        });

        call_1 = findViewById(R.id.call_1);
        call_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+91 20711 77308"));
                startActivity(intent);
            }
        });

        call_2 = findViewById(R.id.call_2);
        call_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+91 20711 73190"));
                startActivity(intent);
            }
        });

        Book_2 = findViewById(R.id.Book_2);
        Book_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorsActivity.this, appointment.class);
                startActivity(intent);
            }
        });

        call_3 = findViewById(R.id.call_3);
        call_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:020 7117 7292"));
                startActivity(intent);
            }
        });

        Book_3 = findViewById(R.id.Book_3);
        Book_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DoctorsActivity.this, appointment.class);
                startActivity(intent);
            }
        });
    }
}