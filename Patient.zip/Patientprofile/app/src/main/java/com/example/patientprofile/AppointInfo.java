package com.example.patientprofile;

public class AppointInfo {

    private String name;
    private String age;
    private String gender;
    private String Symptoms;
    private String Mobile;
    private String date;
    private String Time;
    private String Doctor;

    public AppointInfo() {
    }

    public AppointInfo(String name, String age, String gender, String symptoms, String mobile, String date, String time, String doctor) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.Symptoms = symptoms;
        this.Mobile = mobile;
        this.date = date;
        this.Time = time;
        this.Doctor = doctor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSymptoms() {
        return Symptoms;
    }

    public void setSymptoms(String symptoms) {
        Symptoms = symptoms;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getDoctor() {
        return Doctor;
    }

    public void setDoctor(String doctor) {
        Doctor = doctor;
    }
}
