package com.example.patientprofile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class appointment extends AppCompatActivity {

    ImageView back;
    private EditText username, Age, Gender, symptoms, mobile, Date, time, dName;
    private Button appoint;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    AppointInfo appointInfo;
    private String Id;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        appointInfo = new AppointInfo();

        username = findViewById(R.id.username);
        Age = findViewById(R.id.Age);
        Gender = findViewById(R.id.Gender);
        symptoms = findViewById(R.id.symptoms);
        mobile = findViewById(R.id.mobile);
        Date = findViewById(R.id.Date);
        Intent intent = getIntent();
        Id = intent.getStringExtra("Id");
        time = findViewById(R.id.time);
        dName = findViewById(R.id.dName);
        progressDialog = new ProgressDialog(this);
        appoint = findViewById(R.id.appoint);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("AppointInfo");

        appoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Edtname = username.getText().toString();
                String Edtage = Age.getText().toString();
                String Edtgender = Gender.getText().toString();
                String EdtSymptoms = symptoms.getText().toString();
                String EdtMobile = mobile.getText().toString();
                String Edtdate = Date.getText().toString();
                String EdtTime = time.getText().toString();
                String EdtDoctor = dName.getText().toString();

                if (TextUtils.isEmpty(Edtname) && TextUtils.isEmpty(Edtage) && TextUtils.isEmpty(Edtgender) && TextUtils.isEmpty(EdtSymptoms) && TextUtils.isEmpty(EdtMobile) && TextUtils.isEmpty(Edtdate) && TextUtils.isEmpty(EdtTime) && TextUtils.isEmpty(EdtDoctor)) {
                    // if the text fields are empty
                    // then show the below message.
                    Toast.makeText(appointment.this, "Please add some data.", Toast.LENGTH_SHORT).show();
                } else {
                    // else call the method to add
                    // data to our database.
                        addDatatoFirebase(Edtname, Edtage, Edtgender, EdtSymptoms, EdtMobile, Edtdate, EdtTime, EdtDoctor);
                }
            }
        });
    }

    private void addDatatoFirebase(String edtname, String edtage, String edtgender, String edtSymptoms, String edtMobile, String edtdate, String edtTime, String edtDoctor) {

        appointInfo.setName(edtname);
        appointInfo.setAge(edtage);
        appointInfo.setGender(edtgender);
        appointInfo.setSymptoms(edtSymptoms);
        appointInfo.setMobile(edtMobile);
        appointInfo.setDate(edtdate);
        appointInfo.setTime(edtTime);
        appointInfo.setDoctor(edtDoctor);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(appointInfo);
                Toast.makeText(appointment.this, "Book appointment successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(appointment.this, "Try again", Toast.LENGTH_SHORT).show();
            }
        });

    }


}