package com.example.patientprofile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Doctors1 extends AppCompatActivity {

    Button next, previous, call_4, Book_4, call_5, Book_5, call_6, Book_6;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors1);

        next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Doctors1.this, Doctors3.class);
                startActivity(intent);
            }
        });

        previous = findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        call_4 = findViewById(R.id.call_4);
        call_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+91 20485 52165"));
                startActivity(intent);
            }
        });

        Book_4 = findViewById(R.id.Book_4);
        Book_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Doctors1.this, appointment.class);
                startActivity(intent);
            }
        });

        call_5 = findViewById(R.id.call_5);
        call_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+91 20711 77326"));
                startActivity(intent);
            }
        });

        Book_5 = findViewById(R.id.Book_5);
        Book_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Doctors1.this, appointment.class);
                startActivity(intent);
            }
        });

        call_6 = findViewById(R.id.call_6);
        call_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+91 20715 33798"));
                startActivity(intent);
            }
        });

        Book_6 = findViewById(R.id.Book_6);
        Book_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Doctors1.this, appointment.class);
                startActivity(intent);
            }
        });
    }
}