package com.example.patientprofile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private EditText user,email,pass,phn;
    private ImageView logos;
    private TextView register;
    private Button reges;
    private ProgressBar progressBar;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    private DatabaseReference userDataRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        register=findViewById(R.id.alreadyHaveAccount);
        reges=findViewById(R.id.regbut);
        user=findViewById(R.id.usname);
        email=findViewById(R.id.usemail);
        pass=findViewById(R.id.passwords);
        logos=findViewById(R.id.logo);
        phn=findViewById(R.id.phone);
        progressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        userDataRef= FirebaseDatabase.getInstance().getReference().getRoot();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this,LOGIN.class));
            }
        });
        reges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final  String memail = email.getText().toString().trim();
                final  String muser = user.getText().toString().trim();
                final  String mphone = phn.getText().toString().trim();
                final  String mpass = pass.getText().toString().trim();
                if (TextUtils.isEmpty(memail)){
                    email.setError("Email is required");
                    return;
                }
                if (TextUtils.isEmpty(muser)){
                    user.setError("Username is required");
                    return;
                }
                if (TextUtils.isEmpty(mphone)){
                    phn.setError("Phone is required");
                    return;
                }
                if (TextUtils.isEmpty(mpass)){
                    pass.setError("Password is required");
                    return;
                }
                else {
                    progressDialog.setMessage("Creating an Account...");
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();

                    mAuth.createUserWithEmailAndPassword(memail,mpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                String error = task.getException().toString();
                                Toast.makeText(RegisterActivity.this, "Error"+error, Toast.LENGTH_SHORT).show();
                            }
                            else{
                                String currentUserId=mAuth.getCurrentUser().getUid();
                                userDataRef=FirebaseDatabase.getInstance().getReference().child("users").child(currentUserId);
                                HashMap userInfo=new HashMap();
                                userInfo.put("id",currentUserId);
                                userInfo.put("user",muser);
                                userInfo.put("email",memail);
                                userInfo.put("phn",mphone);
                                userInfo.put("pass",mpass);

                                userDataRef.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(RegisterActivity.this, "Sign up Successfully", Toast.LENGTH_SHORT).show();
                                        }
                                        else {
                                            Toast.makeText(RegisterActivity.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                        }
                                        finish();
                                        progressDialog.dismiss();
                                    }
                                });
                                Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }
                        }
                    });
                }
            }
        });
    }
}