package com.example.patientprofile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class doctorregister extends AppCompatActivity {

    private EditText Name1, Gender1, DOB1, Phone1, Email1, Address1, Specalization, IMR, pass;
    private Button save1;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    private DatabaseReference userDataRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorregister);

        Name1 = findViewById(R.id.Name1);
        Gender1 = findViewById(R.id.Gender1);
        DOB1 = findViewById(R.id.DOB1);
        Phone1 = findViewById(R.id.Phone1);
        Email1 = findViewById(R.id.Email1);
        Address1 = findViewById(R.id.Address1);
        Specalization = findViewById(R.id.Specalization);
        IMR = findViewById(R.id.IMR);
        pass = findViewById(R.id.pass);
        save1 = findViewById(R.id.save1);

        progressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        userDataRef= FirebaseDatabase.getInstance().getReference().getRoot();

        save1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final  String mName = Name1.getText().toString().trim();
                final  String mGender = Gender1.getText().toString().trim();
                final  String mDOB = DOB1.getText().toString().trim();
                final  String mPhone = Phone1.getText().toString().trim();
                final  String mEmail= Email1.getText().toString().trim();
                final  String mAddress= Address1.getText().toString().trim();
                final  String mSpecial= Specalization.getText().toString().trim();
                final  String mIMR= IMR.getText().toString().trim();
                final  String mPass = pass.getText().toString().trim();

                if (TextUtils.isEmpty(mName)){
                    Name1.setError("Name is required");
                    return;
                } if (TextUtils.isEmpty(mGender)){
                    Gender1.setError("Gender is required");
                    return;
                } if (TextUtils.isEmpty(mDOB)){
                    DOB1.setError("DOB is required");
                    return;
                } if (TextUtils.isEmpty(mPhone)){
                    Phone1.setError("Phone is required");
                    return;
                } if (TextUtils.isEmpty(mEmail)){
                    Email1.setError("Email is required");
                    return;
                } if (TextUtils.isEmpty(mAddress)){
                    Address1.setError("Address is required");
                    return;
                } if (TextUtils.isEmpty(mSpecial)){
                    Specalization.setError("Specialization is required");
                    return;
                } if (TextUtils.isEmpty(mIMR)){
                    IMR.setError("Height is required");
                    return;
                } if (TextUtils.isEmpty(mPass)){
                    pass.setError("Password is required");
                    return;
                } else {
                    progressDialog.setMessage("Creating an Account...");
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();

                    mAuth.createUserWithEmailAndPassword(mEmail, mPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                String error = task.getException().toString();
                                Toast.makeText(doctorregister.this, "Error"+error, Toast.LENGTH_SHORT).show();
                            } else {
                                String currentUserId=mAuth.getCurrentUser().getUid();
                                userDataRef=FirebaseDatabase.getInstance().getReference().child("users").child(currentUserId);
                                HashMap userInfo=new HashMap();
                                userInfo.put("id",currentUserId);
                                userInfo.put("name",mName);
                                userInfo.put("Gender",mGender);
                                userInfo.put("DOB",mDOB);
                                userInfo.put("Phone",mPhone);
                                userInfo.put("Email",mEmail);
                                userInfo.put("Address",mAddress);
                                userInfo.put("Specialization",mSpecial);
                                userInfo.put("Height",mIMR);
                                userInfo.put("Pass",mPass);
                                userInfo.put("Doctor","Yes");

                                userDataRef.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(doctorregister.this, "Sign up Successfully", Toast.LENGTH_SHORT).show();
                                        }
                                        else {
                                            Toast.makeText(doctorregister.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                        }
                                        finish();
                                        progressDialog.dismiss();
                                    }
                                });
                                Intent intent = new Intent(doctorregister.this,MainActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }
                        }
                    });
                }

            }
        });

    }
}