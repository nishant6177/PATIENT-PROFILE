package com.example.patientprofile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class patientregister extends AppCompatActivity {

    private EditText Name, Gender, DOB, Phone, Email, Address, DiseaseHistory, Height, Weight, pass1;
    private Button save;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    private DatabaseReference userDataRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patientregister);

        Name = findViewById(R.id.Name);
        Gender = findViewById(R.id.Gender);
        DOB = findViewById(R.id.DOB);
        Phone = findViewById(R.id.Phone);
        Email = findViewById(R.id.Email);
        Address = findViewById(R.id.Address);
        DiseaseHistory = findViewById(R.id.DiseaseHistory);
        Height = findViewById(R.id.Height);
        Weight = findViewById(R.id.Weight);
        pass1 = findViewById(R.id.pass1);
        save = findViewById(R.id.save);

        progressDialog=new ProgressDialog(this);
        mAuth=FirebaseAuth.getInstance();
        userDataRef= FirebaseDatabase.getInstance().getReference().getRoot();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final  String mName = Name.getText().toString().trim();
                final  String mGender = Gender.getText().toString().trim();
                final  String mDOB = DOB.getText().toString().trim();
                final  String mPhone = Phone.getText().toString().trim();
                final  String mEmail= Email.getText().toString().trim();
                final  String mAddress= Address.getText().toString().trim();
                final  String mDisease= DiseaseHistory.getText().toString().trim();
                final  String mHeight= Height.getText().toString().trim();
                final  String mWeight= Weight.getText().toString().trim();
                final  String mPass = pass1.getText().toString().trim();

                if (TextUtils.isEmpty(mName)){
                    Name.setError("Name is required");
                    return;
                } if (TextUtils.isEmpty(mGender)){
                    Gender.setError("Gender is required");
                    return;
                } if (TextUtils.isEmpty(mDOB)){
                    DOB.setError("DOB is required");
                    return;
                } if (TextUtils.isEmpty(mPhone)){
                    Phone.setError("Phone is required");
                    return;
                } if (TextUtils.isEmpty(mEmail)){
                    Email.setError("Email is required");
                    return;
                } if (TextUtils.isEmpty(mAddress)){
                    Address.setError("Address is required");
                    return;
                } if (TextUtils.isEmpty(mDisease)){
                    DiseaseHistory.setError("DH is required");
                    return;
                } if (TextUtils.isEmpty(mHeight)){
                    Height.setError("Height is required");
                    return;
                } if (TextUtils.isEmpty(mWeight)){
                    Weight.setError("Weight is required");
                    return;
                } if (TextUtils.isEmpty(mPass)){
                    pass1.setError("Password is required");
                    return;
                } else {
                    progressDialog.setMessage("Creating an Account...");
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();

                    mAuth.createUserWithEmailAndPassword(mEmail, mPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                String error = task.getException().toString();
                                Toast.makeText(patientregister.this, "Error"+error, Toast.LENGTH_SHORT).show();
                            } else {
                                String currentUserId=mAuth.getCurrentUser().getUid();
                                userDataRef=FirebaseDatabase.getInstance().getReference().child("users").child(currentUserId);
                                HashMap userInfo=new HashMap();
                                userInfo.put("id",currentUserId);
                                userInfo.put("name",mName);
                                userInfo.put("Gender",mGender);
                                userInfo.put("DOB",mDOB);
                                userInfo.put("Phone",mPhone);
                                userInfo.put("Email",mEmail);
                                userInfo.put("Address",mAddress);
                                userInfo.put("Disease",mDisease);
                                userInfo.put("Height",mHeight);
                                userInfo.put("Weight",mWeight);
                                userInfo.put("Pass",mPass);
                                userInfo.put("Patient","Yes");

                                userDataRef.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(patientregister.this, "Sign up Successfully", Toast.LENGTH_SHORT).show();
                                        }
                                        else {
                                            Toast.makeText(patientregister.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                        }
                                        finish();
                                        progressDialog.dismiss();
                                    }
                                });
                                Intent intent = new Intent(patientregister.this,MainActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }
                        }
                    });
                }
            }
        });
    }
}